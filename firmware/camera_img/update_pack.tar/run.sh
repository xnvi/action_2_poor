#!/bin/sh

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/app/lib
cd /home/ko/
./load3516ev200 -i -sensor0 imx335
cd /home/app/lib/
insmod ./ssp_st7789_drv.ko
cd /home/app/

# only for debug, stop auto run
# exit 0

./camera &
